# Active learning for phosphine modified Cu

CSV inputs and Python scripts for regression, candidate prediction, SHAP analysis and molecular mapping. Results are generated when the scripts run; no precomputed results are required.

## Setup and run

Tested with Python 3.8.8 on Windows x64. From this directory in PowerShell:

```powershell
py -3.8 -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
.venv\Scripts\python run_regression.py --jobs 2
.venv\Scripts\python plot_regression.py
```

If `py -3.8` is unavailable, use the path to a Python 3.8 x64 executable. Outputs are written to `outputs/replay/` and `outputs/regression_figures/`. The regression command fits 160 models for each configuration: all 45 features in round 1, and each of the one-to-five feature prefixes in both DFT stages, for 1,760 fits in total.

Optional analyses:

```powershell
.venv\Scripts\python run_molecular_map.py
.venv\Scripts\python select_features.py --jobs 2
```

The map writes coordinates and figures to `outputs/molecular_map/`. Forward selection writes scores, selected features and saved permutations to `outputs/new_feature_selection/`; its 66,240 fits take longer. This is a new seeded search and can select different features from the historical combinations used by the main regression script.

Scripts refuse to overwrite an existing output directory. For a repeat run, choose a new path, for example `run_regression.py --output outputs/repeat`. To plot that run, use `plot_regression.py --input outputs/repeat --output outputs/repeat_figures`. Use `--stage round1`, `--stage round2` or `--stage final127` to run one regression stage; `--no-candidates` disables all candidate and prospective-experiment reads and exports.

## Input files

| Directory | Measured molecules | Descriptor columns | Candidates |
| --- | ---: | ---: | ---: |
| `data/round1/` | 93 | 45 | 2,459 |
| `data/round2/` | 108 | 54 | 172 |
| `data/final127/` | 127 | 54 | None |

* `features.csv`, `targets.csv`: header-free numerical training inputs. Row order matches `molecules.csv`, which contains IDs, CAS, experimental/calculation SMILES and measured values.
* `feature_names.csv`: descriptor names and zero-based column indices.
* `test_indices_*.csv`: the 160 saved held-out membership lists, with zero-based row indices.
* `candidate_features.csv`, `candidates.csv`: aligned candidate descriptors and identities. No artificial target values are used.
* `prospective_experiments.csv`: the 15 or 19 later measurements, used only after prediction; `candidate_index` is zero based.
* `data/molecular_map_input.csv`: the 2,475-entry map universe, with SMILES and source groups.

`settings.py` defines the model parameters, 160 repeats and selected descriptor indices. All regression targets and predictions are in **percentage points**, without logarithmic or exponential conversion. Candidate means and standard deviations use the same 160-model matrix (round 1: ddof=1; round 2: ddof=0). Outputs include molecule-level held-out means, candidate means, per-model predictions and split indices, metrics and five-feature SHAP values. Input files are not overwritten.

## Interpretation

Development MAE is calculated from each molecule's mean held-out prediction; `pearson_r_squared` is squared Pearson correlation. These are repeated random holdouts, not k-fold CV; early stopping and feature selection use development data. Prospective experimental performance is reported separately. SHAP averages the signed values from the full fitted boosters, then summarizes their absolute magnitude across molecules.

The saved holdout memberships and historical selected features are retained. Training rows use their ascending complementary order and the model seed is fixed to 0. The complete historical training permutations were not recovered, so exact agreement with every historical prediction is not promised. The author-confirmed historical Table S6 method is a mean over 160 models.

This package covers the supplied numerical-descriptor regression and map workflows. Classification/Bayesian programs and descriptor/conformer generation are separate. Transport, NMR and isotope-analysis code is available in the independent [spatial reaction and transport repository](https://github.com/wangchengxmu/co2rr-spatial-reaction-transport).
