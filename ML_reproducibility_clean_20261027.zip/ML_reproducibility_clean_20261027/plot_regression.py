"""Render new regression/SHAP outputs, with no access to training targets beyond exported results."""
import argparse, json
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from settings import ROOT, load_configs, input_hashes, ensure_inputs_unchanged

def save(fig, folder, name):
    fig.savefig(folder/(name+'.png'),dpi=300,bbox_inches='tight')
    fig.savefig(folder/(name+'.pdf'),bbox_inches='tight')
    plt.close(fig)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--input',default='outputs/replay')
    parser.add_argument('--output',default='outputs/regression_figures')
    args=parser.parse_args()
    src=ROOT/args.input;out=(ROOT/args.output).resolve()
    if (ROOT/'outputs').resolve() not in out.parents:raise ValueError('Output must be under outputs/.')
    before=input_hashes();out.mkdir(parents=True,exist_ok=False)
    fonts={f.name for f in font_manager.fontManager.ttflist}
    plt.rcParams.update({'font.family':'Arial' if 'Arial' in fonts else 'DejaVu Sans','font.size':11})
    configs=load_configs()
    for stage,cfg in configs.items():
        folder=src/stage/f"{len(cfg['selected_features'])}_features"
        data=pd.read_csv(folder/'heldout_predictions.csv')
        fig,ax=plt.subplots(figsize=(5.4,4.6))
        ax.scatter(data.target_pp,data.heldout_mean,s=25,color='#235a85',alpha=.85)
        lo=min(data.target_pp.min(),data.heldout_mean.min())-2;hi=max(data.target_pp.max(),data.heldout_mean.max())+2
        ax.plot([lo,hi],[lo,hi],color='grey',ls='--',lw=1)
        ax.set(xlabel='Measured change in FE (percentage points)',ylabel='Mean held-out prediction (percentage points)',
               title=f'{stage}: development validation',xlim=(lo,hi),ylim=(lo,hi))
        mae=np.abs(data.target_pp-data.heldout_mean).mean()
        ax.text(.04,.96,f'MAE = {mae:.3f} percentage points',transform=ax.transAxes,va='top',fontsize=10)
        fig.tight_layout();save(fig,out,stage+'_validation')
        later=folder/'prospective_comparison.csv'
        if later.exists():
            df=pd.read_csv(later);fig,ax=plt.subplots(figsize=(5.4,4.6))
            ax.scatter(df.delta_FE_pp,df.prediction_mean,s=35,color='#235a85',label='160-model mean')
            lo=min(df.delta_FE_pp.min(),df.prediction_mean.min())-2
            hi=max(df.delta_FE_pp.max(),df.prediction_mean.max())+2
            ax.plot([lo,hi],[lo,hi],color='grey',ls='--',lw=1)
            ax.set(xlabel='Measured change in FE (percentage points)',ylabel='Candidate prediction (percentage points)',
                   title=f'{stage}: {len(df)} prospective compounds')
            ax.legend(fontsize=9);fig.tight_layout();save(fig,out,stage+'_prospective')
        if (folder/'mean_SHAP.csv').exists():
            sv=np.loadtxt(folder/'mean_SHAP.csv',delimiter=',')
            x=np.loadtxt(ROOT/'data'/stage/'features.csv',delimiter=',')[:,cfg['selected_features']]
            display={'Atom1_ESPAllArea_Ang_2_':'P-atom openness','SurfaceEffAtomNum':'Surface area indicator',
                     'Atom1_LEAEAllAverage':'P-atom LEAE','MolecularSizeMedium':'Molecular width',
                     'Atom1_ALIEMinValue':'P-atom ALIE','ODIHOMO':'ODI of HOMO','Atom1_ESPPi_kcal_mol_':'P-atom ESP separation'}
            names=[display.get(n,n) for n in cfg['selected_feature_names']]
            fig,axes=plt.subplots(2,3,figsize=(12,7.2),layout='constrained')
            imp=np.abs(sv).mean(0);order=np.argsort(imp)
            axes[0,0].barh(np.array(names)[order],imp[order],color='#235a85')
            axes[0,0].set(xlabel='Mean absolute averaged SHAP',title='Ensemble interpretation')
            for j,ax in enumerate(axes.flat[1:]):
                sc=ax.scatter(x[:,j],sv[:,j],c=data.target_pp,cmap='coolwarm',s=20,vmin=data.target_pp.min(),vmax=data.target_pp.max())
                ax.axhline(0,color='grey',lw=.6)
                ax.set(xlabel=names[j],ylabel='Averaged SHAP value')
            fig.colorbar(sc,ax=list(axes.flat[1:]),shrink=.8,label='Measured change in FE (percentage points)')
            save(fig,out,stage+'_SHAP')
    ensure_inputs_unchanged(before)
    print('Regression, prospective and SHAP figures written to',args.output)

if __name__=='__main__':main()
