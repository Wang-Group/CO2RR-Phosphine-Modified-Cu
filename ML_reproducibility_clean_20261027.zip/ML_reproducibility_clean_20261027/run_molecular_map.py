"""Rebuild the original map workflow, writing all derived data to outputs/."""
import os
os.environ.setdefault('OMP_NUM_THREADS','1')
from pathlib import Path
import argparse, hashlib, json
import numpy as np
import pandas as pd
from rdkit import Chem, RDLogger
from rdkit.Chem import AllChem
from sklearn.manifold import TSNE
from sklearn.cluster import KMeans
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from settings import ROOT, input_hashes, ensure_inputs_unchanged


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',default='outputs/molecular_map')
    args=parser.parse_args()
    out=(ROOT/args.output).resolve()
    if (ROOT/'outputs').resolve() not in out.parents:raise ValueError('Output must be under outputs/.')
    if out.exists():raise FileExistsError('Choose a new output directory: '+str(out))
    snapshot=input_hashes()
    RDLogger.DisableLog('rdApp.*')
    src=ROOT/'data/molecular_map_input.csv'
    before=hashlib.sha256(src.read_bytes()).hexdigest()
    data=pd.read_csv(src)
    fingerprints=[]; invalid=[]; no_phosphorus=[]
    for i,s in enumerate(data.SMILES):
        m=Chem.MolFromSmiles(s)
        if m is None:
            invalid.append(i+1);continue
        atoms=[a.GetIdx() for a in m.GetAtoms() if a.GetAtomicNum()==15]
        # Preserve the inspected historical behavior: RDKit uses all atoms when
        # fromAtoms is empty. Record these entries explicitly instead of deleting.
        if not atoms:no_phosphorus.append({'row':i+1,'smiles':s,'fingerprint_scope':'all atoms (historical empty fromAtoms behavior)'})
        fingerprints.append(np.asarray(AllChem.GetMorganFingerprintAsBitVect(m,5,fromAtoms=atoms,nBits=512)))
    if invalid:raise ValueError('Invalid SMILES rows; no silent zero fingerprints: '+str(invalid))
    fp=np.asarray(fingerprints)
    # Explicit defaults match the inspected historical sklearn-style workflow.
    cluster=KMeans(n_clusters=3,random_state=87,n_init=10).fit_predict(fp)
    labels=pd.Series(cluster).value_counts().index.tolist()
    data['Cluster']=[labels.index(v) for v in cluster]
    coordinates=TSNE(n_components=2,random_state=42,init='random',learning_rate=200.,perplexity=30.,n_iter=1000).fit_transform(fp)
    data['TSNE_Dimension_1']=coordinates[:,0];data['TSNE_Dimension_2']=coordinates[:,1]
    out.mkdir(parents=True,exist_ok=False)
    data.to_csv(out/'map_coordinates.csv',index=False)
    np.savez_compressed(out/'fingerprints.npz',fingerprints=fp)
    available={f.name for f in font_manager.fontManager.ttflist}
    font='Arial' if 'Arial' in available else 'DejaVu Sans'
    plt.rcParams['font.family']=font
    fig,ax=plt.subplots(figsize=(7,5.5))
    colors=['#228B22','#4169E1','purple']
    for c in range(3):
        mask=(data.Source_Label=='commercial')&(data.Cluster==c)
        ax.scatter(*coordinates[mask].T,s=10,c=colors[c],label=f'Class {c+1}')
    for label,color in [('Initial dataset','#ffcc66'),('1ˢᵗ Round','#FF69B4'),('2ⁿᵈ Round','red')]:
        mask=data.Source_Label==label
        ax.scatter(*coordinates[mask].T,s=14,c=color,label=label)
    ax.set(xlabel='t-SNE dimension 1',ylabel='t-SNE dimension 2')
    ax.legend(fontsize=9);fig.tight_layout()
    fig.savefig(out/'molecular_map.png',dpi=400);fig.savefig(out/'molecular_map.pdf');plt.close(fig)
    after=hashlib.sha256(src.read_bytes()).hexdigest()
    assert before==after
    ensure_inputs_unchanged(snapshot)
    (out/'run_info.json').write_text(json.dumps({'n':len(data),'plot_font':font,'groups':data.Source_Label.value_counts().to_dict(),
        'input_sha256_before':before,'input_sha256_after':after,'invalid_smiles':invalid,'non_phosphorus_records':no_phosphorus,
        'note':'New layout from fixed explicit settings; exact historic t-SNE coordinates were not recovered.'},indent=2),encoding='utf-8')
    print('Map completed for',len(data),'molecules; source unchanged.')

if __name__=='__main__':main()
