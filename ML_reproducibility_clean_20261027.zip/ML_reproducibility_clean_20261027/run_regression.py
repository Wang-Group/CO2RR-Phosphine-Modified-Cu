"""Train from frozen numeric inputs; never load reference predictions for fitting.

Replays saved held-out memberships along the recorded feature path. The original
within-training permutation was not saved; the sorted complement is explicit.
"""
import os
os.environ.setdefault('OMP_NUM_THREADS','1')
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
from pathlib import Path
import argparse, concurrent.futures, json, platform, time, warnings
import numpy as np
import pandas as pd
import scipy, sklearn, xgboost
from xgboost import XGBRegressor

from settings import ROOT, load_configs, input_hashes, ensure_inputs_unchanged

def aggregate_candidate_predictions(predictions,ddof=0):
    p=np.asarray(predictions,dtype=float)
    if p.ndim!=2 or p.shape[0]<2 or not np.isfinite(p).all():
        raise ValueError('Expected finite predictions with shape (models, candidates).')
    return p.mean(axis=0),p.std(axis=0,ddof=ddof)

def heldout_summary(full_predictions,test_indices):
    p=np.asarray(full_predictions,dtype=float)
    mask=np.zeros_like(p,dtype=bool)
    for i,idx in enumerate(test_indices):mask[i,idx]=True
    counts=mask.sum(axis=0)
    if not (counts>0).all():raise ValueError('At least one molecule has no held-out predictions.')
    mean=(p*mask).sum(axis=0)/counts
    std=np.sqrt((((p-mean)**2)*mask).sum(axis=0)/counts)
    return mean,std,counts

def metrics(y,p):
    return {'mae_pp':float(np.abs(y-p).mean()),
            'pearson_r_squared':float(np.corrcoef(y,p)[0,1]**2),
            'n':len(y)}

def fit_one(task):
    i,x,y,candidates,test,config,with_shap=task
    train=np.setdiff1d(np.arange(len(y)),test)
    model=XGBRegressor(**config['model'],early_stopping_rounds=config['early_stopping_rounds'])
    model.fit(x[train],y[train],eval_set=[(x[test],y[test])],verbose=False)
    full=model.predict(x)
    pred=model.predict(candidates) if candidates is not None else None
    shap_values=None
    if with_shap:
        import shap
        with warnings.catch_warnings():
            warnings.simplefilter('ignore',UserWarning)
            shap_values=shap.TreeExplainer(model).shap_values(x)
    return i,full,pred,int(model.best_iteration),shap_values

def run_stage(stage,config,out,jobs,prefixes,predict_candidates=True):
    data=ROOT/'data'/stage
    x=np.loadtxt(data/'features.csv',delimiter=','); y=np.loadtxt(data/'targets.csv',delimiter=',')
    ids=pd.read_csv(data/'molecules.csv')
    if x.shape!=(config['n_train'],config['n_features']) or y.shape!=(len(x),):raise ValueError('Input dimensions mismatch')
    if not np.isfinite(x).all() or not np.isfinite(y).all():raise ValueError('Nonfinite training values')
    if predict_candidates and stage in ('round1','round2'):
        for name in ['candidate_features.csv','candidates.csv','prospective_experiments.csv']:
            if not (data/name).is_file():
                raise FileNotFoundError(f'Missing {stage}/{name}; use --no-candidates to disable candidate prediction.')
    candidates=np.loadtxt(data/'candidate_features.csv',delimiter=',') if predict_candidates and (data/'candidate_features.csv').exists() else None
    cids=pd.read_csv(data/'candidates.csv') if candidates is not None else None
    if len(ids)!=len(y) or ids.molecule_id.duplicated().any() or ids.CAS.duplicated().any():
        raise ValueError('Training molecule identifiers are not one-to-one with descriptor rows.')
    # Recovered target CSVs retain eight decimal places; the ID ledger retains
    # more digits. This tolerance covers serialization only, not paper rounding.
    np.testing.assert_allclose(ids.delta_FE_pp.to_numpy(float),y,rtol=0,atol=1e-8)
    if candidates is not None:
        if candidates.shape!=(len(cids),config['n_features']) or not np.isfinite(candidates).all() or cids.CAS.duplicated().any():
            raise ValueError('Candidate identities or descriptors are misaligned.')
    results=[]; selected=config['selected_features']
    counts=[len(selected)] if prefixes=='selected' or stage=='round1' else list(range(1,len(selected)+1))
    for count in counts:
        start=time.monotonic()
        selected_now=selected[:count]; xs=x[:,selected_now]
        cs=candidates[:,selected_now] if candidates is not None else None
        tests=np.loadtxt(data/f'test_indices_{count}.csv',delimiter=',',dtype=int)
        if tests.shape[0]!=config['n_repeats'] or tests.min()<0 or tests.max()>=len(y) or any(len(set(t))!=len(t) for t in tests):
            raise ValueError('Invalid held-out membership indices.')
        with_shap=stage!='round1' and count==len(selected)
        tasks=[(i,xs,y,cs,test,config,with_shap) for i,test in enumerate(tests)]
        full=np.empty((len(tests),len(y))); cp=np.empty((len(tests),len(cs))) if cs is not None else None
        iterations=np.zeros(len(tests),dtype=int); shapes=[]
        with concurrent.futures.ProcessPoolExecutor(max_workers=jobs) as pool:
            for completed,(i,f,c,b,s) in enumerate(pool.map(fit_one,tasks),1):
                full[i]=f; iterations[i]=b
                if cp is not None:cp[i]=c
                if s is not None:shapes.append(s)
                if completed%40==0:print(f'{stage} features={count}: {completed}/{len(tasks)} models',flush=True)
        dst=out/stage/f'{count}_features';dst.mkdir(parents=True)
        mean,std,n=heldout_summary(full,tests)
        detail=ids[['molecule_id','CAS']].copy()
        detail['target_pp']=y;detail['heldout_mean']=mean;detail['heldout_std']=std;detail['heldout_count']=n
        detail.to_csv(dst/'heldout_predictions.csv',index=False)
        np.savez_compressed(dst/'all_model_predictions.npz',full_predictions=full,test_indices=tests,
                            training_indices=np.array([np.setdiff1d(np.arange(len(y)),v) for v in tests]),
                            candidate_predictions=cp if cp is not None else np.empty((len(tests),0)),best_iterations=iterations)
        per_model=[]
        for model_index,test in enumerate(tests):
            m=metrics(y[test],full[model_index,test])
            per_model.append({'model_index':model_index,'n_train':len(y)-len(test),'n_test':len(test),
                              'best_iteration':int(iterations[model_index]),**m})
        pd.DataFrame(per_model).to_csv(dst/'per_model_metrics.csv',index=False)
        result={'stage':stage,'n_features':count,'feature_indices':selected_now,'n_models':len(tests),
                'metrics':metrics(y,mean),'model_random_state':config['model']['random_state'],
                'training_order':config['reconstructed_training_order']}
        if cp is not None:
            ddof=1 if stage=='round1' else 0
            cm,csd=aggregate_candidate_predictions(cp,ddof)
            report=cids.copy();report['prediction_mean']=cm;report['prediction_std']=csd
            report.to_csv(dst/'candidate_predictions.csv',index=False)
            result['candidate_n']=len(cm);result['candidate_std_ddof']=ddof
            # These later measurements are used only after fitting and prediction.
            later=pd.read_csv(data/'prospective_experiments.csv')
            ii=later.candidate_index.to_numpy(dtype=int);truth=later.delta_FE_pp.to_numpy(float)
            if ii.min()<0 or ii.max()>=len(cids) or not np.array_equal(cids.iloc[ii].CAS.to_numpy(),later.CAS.to_numpy()):
                raise ValueError('Prospective experimental identifiers do not match candidate rows.')
            if set(later.molecule_id)&set(ids.molecule_id):
                raise ValueError('Prospective molecules must be absent from this training stage.')
            later['prediction_mean']=cm[ii];later['prediction_std']=csd[ii]
            later.to_csv(dst/'prospective_comparison.csv',index=False)
            result['prospective']={'n':len(ii),'mae_pp':float(np.abs(cm[ii]-truth).mean()),
                                   'mean_prediction_pp':float(cm[ii].mean())}
        if shapes:
            sv=np.mean(shapes,axis=0)
            np.savetxt(dst/'mean_SHAP.csv',sv,delimiter=',')
            pd.DataFrame({'feature':config['selected_feature_names'],'mean_abs_SHAP':np.abs(sv).mean(axis=0)}).to_csv(dst/'SHAP_importance.csv',index=False)
        result['elapsed_seconds']=round(time.monotonic()-start,3)
        (dst/'metrics.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
        results.append(result)
        print(json.dumps({k:result[k] for k in ['stage','n_features','metrics','elapsed_seconds']}),flush=True)
    return results

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--stage',choices=['all','round1','round2','final127'],default='all')
    parser.add_argument('--prefixes',choices=['all','selected'],default='all')
    parser.add_argument('--jobs',type=int,default=2)
    parser.add_argument('--no-candidates',action='store_true',help='Run regression without reading candidate or prospective-experiment files.')
    parser.add_argument('--output',default='outputs/replay')
    args=parser.parse_args()
    out=(ROOT/args.output).resolve()
    if ROOT.resolve() not in out.parents or (ROOT/'outputs').resolve() not in out.parents:
        raise ValueError('Output must be a new subdirectory of outputs/.')
    out.mkdir(parents=True,exist_ok=False)
    before=input_hashes(include_candidates=not args.no_candidates)
    versions={'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,
              'scikit-learn':sklearn.__version__,'xgboost':xgboost.__version__,'pandas':pd.__version__}
    (out/'environment.json').write_text(json.dumps(versions,indent=2),encoding='utf-8')
    configs=load_configs()
    results=[]
    for stage,config in configs.items():
        if args.stage in ('all',stage):results.extend(run_stage(stage,config,out,args.jobs,args.prefixes,not args.no_candidates))
    ensure_inputs_unchanged(before)
    (out/'summary.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
    print('Completed; inputs unchanged.',flush=True)

if __name__=='__main__':main()
