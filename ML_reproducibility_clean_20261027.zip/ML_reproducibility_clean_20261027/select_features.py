"""Deterministic forward selection using the original model and 160 resamples.

This is a NEW selection run. Historical selection permutations were not saved.
Each candidate feature gets an explicit, saved permutation sequence, matching
the original use of fresh permutations per candidate without claiming its seed.
"""
import os
os.environ.setdefault('OMP_NUM_THREADS','1')
from pathlib import Path
import argparse, concurrent.futures, json, time
import numpy as np
from xgboost import XGBRegressor
from settings import ROOT, load_configs, input_hashes, ensure_inputs_unchanged

def evaluate_feature(task):
    candidate,selected,x,y,config,permutations=task
    cols=selected+[candidate]
    x=x[:,cols]; point=round(len(y)*config['train_fraction'])
    errors=[]
    for perm in permutations:
        train,test=perm[:point],perm[point:]
        model=XGBRegressor(**config['model'],early_stopping_rounds=config['early_stopping_rounds'])
        model.fit(x[train],y[train],eval_set=[(x[test],y[test])],verbose=False)
        errors.append(float(np.mean((model.predict(x[test])-y[test])**2)))
    return candidate,float(np.mean(errors))

def select_one(stage,config,jobs,out,seed):
    x=np.loadtxt(ROOT/'data'/stage/'features.csv',delimiter=',')
    y=np.loadtxt(ROOT/'data'/stage/'targets.csv',delimiter=',')
    rng=np.random.RandomState(seed)
    selected=[];rows=[]; permutations_saved={}
    start=time.monotonic()
    # The reference notebooks explicitly specify starting feature 47.
    for step in range(5):
        candidates=[47] if step==0 else [j for j in range(x.shape[1]) if j not in selected]
        tasks=[]
        for j in candidates:
            perm=np.asarray([rng.permutation(len(y)) for _ in range(config['n_repeats'])])
            permutations_saved[f'step{step+1}_candidate{j}']=perm
            tasks.append((j,list(selected),x,y,config,perm))
        with concurrent.futures.ProcessPoolExecutor(max_workers=jobs) as pool:
            results=list(pool.map(evaluate_feature,tasks))
        # Exclude already-selected features explicitly; no zero placeholders/index offsets.
        chosen,loss=min(results,key=lambda z:(z[1],z[0]))
        selected.append(chosen)
        rows.append({'n_features':step+1,'selected':list(selected),'selection_mse':loss,
                     'candidate_scores':[{'feature':f,'mse':v} for f,v in results]})
        print(stage,'step',step+1,'selected',selected,'MSE',round(loss,6),flush=True)
    folder=out/stage;folder.mkdir(parents=True)
    np.savez_compressed(folder/'selection_permutations.npz',**permutations_saved)
    report={'stage':stage,'seed':seed,'n_repeats_per_candidate':config['n_repeats'],
            'selected':selected,'historical_selected':config['selected_features'],
            'same_selected_sequence':selected==config['selected_features'],
            'note':'New seeded selection; no original feature-search permutations were saved. Full-data exploratory selection is not independent validation.',
            'steps':rows,'elapsed_seconds':time.monotonic()-start}
    (folder/'selection.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    return report

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--jobs',type=int,default=2)
    parser.add_argument('--seed',type=int,default=20261027)
    parser.add_argument('--output',default='outputs/new_feature_selection')
    args=parser.parse_args();out=(ROOT/args.output).resolve()
    if (ROOT/'outputs').resolve() not in out.parents:raise ValueError('Output must be under outputs/.')
    out.mkdir(parents=True,exist_ok=False);before=input_hashes()
    configs=load_configs()
    result=[select_one(stage,configs[stage],args.jobs,out,args.seed) for stage in ['round2','final127']]
    (out/'summary.json').write_text(json.dumps([{k:v for k,v in r.items() if k!='steps'} for r in result],indent=2))
    ensure_inputs_unchanged(before)

if __name__=='__main__':main()
