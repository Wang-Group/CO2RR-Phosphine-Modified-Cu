"""Model settings and input protection shared by the executable scripts."""
from pathlib import Path
import csv, hashlib

ROOT = Path(__file__).resolve().parent
MODEL = dict(n_estimators=350, learning_rate=0.03, max_depth=8,
             verbosity=0, booster='gbtree', reg_alpha=0.049787068367863944,
             reg_lambda=0.049787068367863944, gamma=0.006737946999085467,
             subsample=0.5, objective='reg:squarederror', n_jobs=1,
             random_state=0, tree_method='exact', eval_metric='rmse')

def load_configs():
    stages = [('round1',93,45,list(range(45))),
              ('round2',108,54,[47,30,46,20,51]),
              ('final127',127,54,[47,30,46,9,52])]
    configs = {}
    for stage,n,f,selected in stages:
        with (ROOT/'data'/stage/'feature_names.csv').open(encoding='utf-8',newline='') as handle:
            rows = list(csv.DictReader(handle))
        if [int(r['feature_index']) for r in rows] != list(range(f)):
            raise ValueError('Feature-name indices are not aligned: '+stage)
        configs[stage] = dict(n_train=n,n_features=f,selected_features=selected,
            selected_feature_names=[rows[i]['feature_name'] for i in selected],
            n_repeats=160,train_fraction=0.85,early_stopping_rounds=150,
            reconstructed_training_order='ascending complement of saved test indices',
            model=MODEL.copy())
    return configs

def input_hashes(include_candidates=True):
    optional = {'candidate_features.csv','candidates.csv','prospective_experiments.csv'}
    return {p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted((ROOT/'data').rglob('*.csv'))
            if include_candidates or p.name not in optional}

def ensure_inputs_unchanged(before):
    changed = [name for name,h in before.items()
               if not (ROOT/name).is_file() or hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=h]
    if changed:raise RuntimeError('Input changed during execution: '+str(changed))
